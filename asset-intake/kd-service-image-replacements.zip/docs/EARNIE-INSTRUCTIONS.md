# Earnie Instructions — Replace Two Service Images

Repository: `JZGaskin/kd-auto-electric`
Branch: `main`

Use the attached replacement package to update only the Automotive Electric and Intoxalock service images.

Do not change DNS.

## Install

Copy the included files into:

`public/images/services/`

The package intentionally uses the existing filenames:

- `automotive-electric.webp`
- `intoxalock.webp`

Replace the current files with these new versions.

Because the filenames remain unchanged, existing homepage and service-page references should continue working without code changes. Confirm that this is true after replacement.

## Automotive Electric

Use:

`/images/services/automotive-electric.webp`

This image is intended to communicate:

- battery testing
- charging-system diagnosis
- alternator-related diagnosis
- wiring and circuit troubleshooting
- use of a multimeter
- use of a diagnostic tablet

Recommended alt text:

`Technician testing a vehicle battery and charging system with a multimeter and diagnostic tablet`

Use it on:

- the homepage Automotive Electric service card
- the Automotive Electric service page near the top of the page

Do not describe the depicted technician as Jeremy or as an actual K&D employee.

## Intoxalock

Use:

`/images/services/intoxalock.webp`

This image is intended to communicate:

- ignition-interlock installation
- under-dashboard wiring access
- device connection and testing
- calibration and service
- maintenance, lockout service, and removal

Recommended alt text:

`Technician installing and testing an ignition interlock device beneath a vehicle dashboard`

Use it on:

- the homepage Intoxalock service card
- the Intoxalock service page near the top of the page

Do not claim that the image shows a particular customer vehicle or an actual K&D employee.

## Source truthfulness

Both replacement images are AI-generated illustrative service images.

They are designed to match the visual style of the current K&D website and to communicate the subject matter more clearly than the previous images.

Do not caption them as documentary photographs of K&D staff, customers, or completed jobs.

Do not add visible “AI-generated” labels to the cards. Simply avoid factual captions that identify people or vehicles.

## Preserve approved content

Do not rewrite owner-approved service wording.

Keep all current business details, phone numbers, redirects, reviews, and page copy unchanged.

## QA

After replacement:

1. Confirm both image URLs return HTTP 200.
2. Confirm both homepage cards display the new images.
3. Confirm both service pages display the new images.
4. Confirm images use consistent card height and `object-cover`.
5. Check desktop, tablet, and 390px mobile crops.
6. Confirm no text or important diagnostic detail is cut off.
7. Confirm no `Photo coming soon` placeholder returns.
8. Run the production build.
9. Deploy the Netlify preview.

Report back with:

- files changed
- build result
- deployed commit SHA
- Netlify preview URL
- desktop screenshot of the service-card grid
- 390px mobile screenshot of both updated cards
